using APIGK2V.Entidades;

namespace APIGK2V.Contratos
{
    public interface IMatchRepositorio : IRepositorioBase<Match>
    {
         
    }
}