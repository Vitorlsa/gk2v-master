using APIGK2V.Entidades;

namespace APIGK2V.Contratos
{
    public interface IPessoaRepositorio : IRepositorioBase<Pessoa>
    {
         
    }
}