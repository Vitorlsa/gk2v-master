using APIGK2V.Entidades;

namespace APIGK2V.Contratos
{
    public interface IPlayerRepositorio : IRepositorioBase<Player>
    {
         
    }
}