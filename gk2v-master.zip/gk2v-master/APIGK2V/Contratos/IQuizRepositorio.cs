using APIGK2V.Entidades;

namespace APIGK2V.Contratos
{
    public interface IQuizRepositorio : IRepositorioBase<Quiz>
    {
         
    }
}