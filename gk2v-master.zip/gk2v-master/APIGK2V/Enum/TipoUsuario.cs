namespace APIGK2V.Enum
{
    public enum TipoUsuario
    {
        Admin = 1,
        Apostador = 0
    }
}