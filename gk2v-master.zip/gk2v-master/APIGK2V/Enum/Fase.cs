namespace APIGK2V.Enum
{
    ///Representa as fases da temporada
    public enum Fase
    {
        Oitavas,
        Quartas,
        SemiFinais,
        Final
    }
}