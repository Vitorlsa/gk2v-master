namespace APIGK2V.Entidades
{
    ////Entidade teste
    public class Pessoa : EntidadeBase
    {
        public string nome { get; set; } 
        public string sobrenome { get; set; }

    }
}