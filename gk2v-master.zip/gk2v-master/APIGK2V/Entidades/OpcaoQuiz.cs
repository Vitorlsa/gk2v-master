namespace APIGK2V.Entidades
{
    public class OpcaoQuiz
    {
        public string Opcao { get; set; }
    }
}