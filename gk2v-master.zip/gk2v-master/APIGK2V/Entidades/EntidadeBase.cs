using MongoDB.Bson;

namespace APIGK2V.Entidades
{
    public class EntidadeBase
    {
        public ObjectId _id { get; set; }     

    }
}