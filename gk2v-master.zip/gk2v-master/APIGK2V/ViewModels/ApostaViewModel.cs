namespace APIGK2V.ViewModels
{
    public class ApostaViewModel
    {
        public int Pontos { get; set; }
        public string  CodigoJogo { get; set; }
    }
}