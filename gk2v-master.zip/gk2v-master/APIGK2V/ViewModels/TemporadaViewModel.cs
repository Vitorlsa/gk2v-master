namespace APIGK2V.ViewModels
{
    public class TemporadaViewModel
    {
        public string Id { get; set; }
        public int Numero { get; set; }
        public int Fase { get; set; }
        public bool TimesMesmaEpoca { get; set; }
        public string Nome { get; set; }
    }
}
