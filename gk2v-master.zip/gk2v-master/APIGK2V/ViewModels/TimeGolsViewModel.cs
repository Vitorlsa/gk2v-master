namespace APIGK2V.ViewModels
{
    public class TimesmGolsViewModel
    {
        public int Gols { get; set; }
        public string Nome { get; set; }
    }
}