namespace APIGK2V.ViewModels
{
    public class RetornoRankingViewModel
    {
        public string Nome { get; set; }
        public int Pontuacao { get; set; }
    }
}