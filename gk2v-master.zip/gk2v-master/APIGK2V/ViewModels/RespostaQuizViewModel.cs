namespace APIGK2V.ViewModels
{
    public class RespostaQuizViewModel
    {
        public string IdUsuario { get; set; }
        public string IdQuiz { get; set; }
        public bool Acertou { get; set; }
    }
}